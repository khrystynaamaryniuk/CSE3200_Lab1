package com.example.k2025_02_15_viewmodel.views.ui.theme

import androidx.compose.ui.graphics.Color

val LightGreen = Color(0xFFA8E6CF)
val MediumGreen = Color(0xFF9BE09E)
val MediumGreen2 = Color(0xFF157019)
val DarkGreen = Color(0xFF1F4B20)
val SoftWhite = Color(0xFFFAFAFA)
val TextDark = Color(0xFF2E7D32)
